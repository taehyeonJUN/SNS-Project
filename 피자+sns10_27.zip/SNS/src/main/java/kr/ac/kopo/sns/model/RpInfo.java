package kr.ac.kopo.sns.model;

import java.util.List;

public class RpInfo {
   List<Rp> list;

   public List<Rp> getList() {
      return list;
   }

   public void setList(List<Rp> list) {
      this.list = list;
   }
   
   
   
   
}