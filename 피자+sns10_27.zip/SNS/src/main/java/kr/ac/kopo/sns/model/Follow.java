package kr.ac.kopo.sns.model;

public class Follow {

	int follow;
	String followI;
	String followY;
	
	
	public int getFollow() {
		return follow;
	}
	public void setFollow(int follow) {
		this.follow = follow;
	}
	public String getFollowI() {
		return followI;
	}
	public void setFollowI(String followI) {
		this.followI = followI;
	}
	public String getFollowY() {
		return followY;
	}
	public void setFollowY(String followY) {
		this.followY = followY;
	}
	
	
	
}
