$(document).ready(function(){
     $(".setting-btn").click(function(){
      $(".delete-btn").slideToggle();
    });
  });