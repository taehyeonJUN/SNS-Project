package hi.pizza.world.pizzamenu;

public class PizzaMenuVo {
	//메뉴판 관련
	private int meId; //메뉴번호
	private String meName; //이름
	private int mePrice; //가격
	private String meSort; //분류
	
	
	
	///메뉴 관련
	public int getMeId() {
		return meId;
	}
	public void setMeId(int meId) {
		this.meId = meId;
	}
	public String getMeName() {
		return meName;
	}
	public void setMeName(String meName) {
		this.meName = meName;
	}
	public int getMePrice() {
		return mePrice;
	}
	public void setMePrice(int mePrice) {
		this.mePrice = mePrice;
	}
	public String getMeSort() {
		return meSort;
	}
	public void setMeSort(String meSort) {
		this.meSort = meSort;
	}
	
	
	
	
	
	
	
	
}
