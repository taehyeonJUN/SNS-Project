package kr.ac.kopo.sns.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.ac.kopo.sns.model.Member;
import kr.ac.kopo.sns.service.memberService;


@Controller
public class RootController {
	@Autowired
	memberService service;
	
	
	@RequestMapping("/")
	String index() {
		return "index";
	}
	
	@GetMapping("/login")
	String login() {
		return "login";
	}

	@PostMapping("/login")
	String login(Member member,HttpSession session) {
		
		if(service.login(member)) {
			session.setAttribute("user", member);
			
			return "home";
		}
		
		return "login";
	}
	
	@RequestMapping("/logout")
	String logout(HttpSession session) {
		
		session.invalidate();
		
		return "login";
	}
	
}
