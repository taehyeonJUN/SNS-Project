package kr.ac.kopo.sns.dao;

import java.util.List;

import kr.ac.kopo.sns.model.Member;

public interface MemberDao {

	int login(Member member);

	void add(Member member);

	List<Member> list();








}
