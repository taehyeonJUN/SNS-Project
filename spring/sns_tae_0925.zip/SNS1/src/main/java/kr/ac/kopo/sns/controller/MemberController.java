package kr.ac.kopo.sns.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.ac.kopo.sns.model.Member;
import kr.ac.kopo.sns.service.memberService;

@Controller
@RequestMapping("/member")
public class MemberController {
	final String path = "member/";
	
	
	@Autowired
	memberService service;
	
	@RequestMapping("/add")
	String add() {
		return path + "add";
	}
	
	
	@PostMapping("/add")
	String add(Member member) {
		service.add(member);
		return "redirect:/login";
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(Model model) {
		List<Member> list = service.list();
	
		
		model.addAttribute("memList",list);
		
		
		return path + "list";
	}






}
