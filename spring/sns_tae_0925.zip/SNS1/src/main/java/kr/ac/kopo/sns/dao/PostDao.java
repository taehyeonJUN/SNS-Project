package kr.ac.kopo.sns.dao;

import java.util.List;

import kr.ac.kopo.sns.model.Member;
import kr.ac.kopo.sns.model.Post;

public interface PostDao {

	List<Post> list(Post vo);

	void add(Post vo);

	void delete(int postNo);

	Post postData(int postNo);

	void update(Post post);

}
