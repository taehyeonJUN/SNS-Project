package kr.ac.kopo.sns.service;

import java.util.List;

import kr.ac.kopo.sns.model.Member;

public interface memberService {

	boolean login(Member member);

	void add(Member member);

	List<Member> list();










}
