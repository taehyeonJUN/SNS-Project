package kr.ac.kopo.sns.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.sns.dao.MemberDao;
import kr.ac.kopo.sns.model.Member;

@Service
public class memberServiceImpl implements memberService {

	@Autowired
	MemberDao dao;

	@Override
	public boolean login(Member member) {
		if(dao.login(member) == 1) 
			return true;
		
		
		return false;
	}

	@Override
	public void add(Member member) {
		dao.add(member);
	}

	@Override
	public List<Member> list() {
		return dao.list();
	}






	
	
}
