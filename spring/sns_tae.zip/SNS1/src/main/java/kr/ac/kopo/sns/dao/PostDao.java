package kr.ac.kopo.sns.dao;

import java.util.List;

import kr.ac.kopo.sns.model.Post;

public interface PostDao {

	List<Post> list();

}
