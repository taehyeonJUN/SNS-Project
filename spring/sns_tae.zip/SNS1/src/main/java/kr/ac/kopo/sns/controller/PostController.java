package kr.ac.kopo.sns.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.ac.kopo.sns.model.Post;
import kr.ac.kopo.sns.service.PostService;

@Controller
@RequestMapping("/post")
public class PostController {

	@Autowired
	PostService service;
	
	final String path="post/";
	
	@GetMapping("list")
	String list(Model model){
		
		List<Post> list = service.list();
		model.addAttribute("list",list);
		
		return path + "list";
	}
	
	
	
}
