package kr.ac.kopo.sns.service;

import java.util.List;

import kr.ac.kopo.sns.model.Post;

public interface PostService {

	List<Post> list();

}
