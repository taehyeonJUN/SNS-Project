package kr.ac.kopo.sns.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.sns.dao.PostDao;
import kr.ac.kopo.sns.model.Post;

@Service
public class PostServiceImpl implements PostService{

	@Autowired
	PostDao dao;
	
	@Override
	public List<Post> list() {
		return dao.list();
	}

}
