package kr.ac.kopo.sns.model;

import org.springframework.web.multipart.MultipartFile;

public class Photo {
	int phoNo;
	MultipartFile phoPhoto;
	int phoPostno;
	
	public int getPhoNo() {
		return phoNo;
	}
	public void setPhoNo(int phoNo) {
		this.phoNo = phoNo;
	}
	
	public int getPhoPostno() {
		return phoPostno;
	}
	public void setPhoPostno(int phoPostno) {
		this.phoPostno = phoPostno;
	}
	public MultipartFile getPhoPhoto() {
		return phoPhoto;
	}
	public void setPhoPhoto(MultipartFile phoPhoto) {
		this.phoPhoto = phoPhoto;
	}




}
