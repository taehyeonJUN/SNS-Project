package kr.ac.kopo.sns.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.sns.model.Member;
import kr.ac.kopo.sns.model.Post;
import kr.ac.kopo.sns.model.Rp;

@Repository
public class PostDaoImpl implements PostDao {

	@Autowired
	SqlSession sql;
	
	@Override
	public List<Post> list(Post vo) {
		return sql.selectList("post.list",vo);
	}

	@Override
	public int add(Post vo) {
		int num = sql.insert("post.add",vo);
		return num;
	}

	@Override
	public void delete(int postNo) {
		sql.delete("post.delete",postNo);
	}

	@Override
	public Post postData(int postNo) {
		return sql.selectOne("post.postData", postNo);
	}

	@Override
	public void update(Post post) {
		sql.update("post.update",post);
	}

	@Override
	public List<Post> list(int postNo) {
		return sql.selectOne("post.list", postNo);
	}


}
