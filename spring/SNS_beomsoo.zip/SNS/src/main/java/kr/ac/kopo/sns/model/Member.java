package kr.ac.kopo.sns.model;

import java.util.Date;

public class Member {
	String memId;
	String memPass;
	String memName;
	String memTel;
	Date memDate;
	String author;
	String intro;
	int memFollow;
	int memFollower;
	
	
	
	
	public String getMemId() {
		return memId;
	}
	public void setMemId(String memId) {
		this.memId = memId;
	}
	public String getMemPass() {
		return memPass;
	}
	public void setMemPass(String memPass) {
		this.memPass = memPass;
	}
	public String getMemName() {
		return memName;
	}
	public void setMemName(String memName) {
		this.memName = memName;
	}
	public String getMemTel() {
		return memTel;
	}
	public void setMemTel(String memTel) {
		this.memTel = memTel;
	}
	public Date getMemDate() {
		return memDate;
	}
	public void setMemDate(Date memDate) {
		this.memDate = memDate;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getIntro() {
		return intro;
	}
	public void setIntro(String intro) {
		this.intro = intro;
	}
	public int getMemFollow() {
		return memFollow;
	}
	public void setMemFollow(int memFollow) {
		this.memFollow = memFollow;
	}
	public int getMemFollower() {
		return memFollower;
	}
	public void setMemFollower(int memFollower) {
		this.memFollower = memFollower;
	}
}
