// const toggleBtn = document.querySelector('.menu-btn');
// const menu = document.querySelector('.nav-btn');

// toggleBtn.addEventListener('click', () => {
//     menu.classList.toggle('active');
// });


// 본문 쩜쩜쩜 토글
const toggleBtn = document.querySelector('.setting-btn');
const menu = document.querySelector('.delete-btn');

toggleBtn.addEventListener('click', () => {
    menu.classList.toggle('active');
});