package kr.ac.kopo.sns.model;

public class Photo {
	int phoNo;
	String phoPhoto;
	int phoPostno;
	
	public int getPhoNo() {
		return phoNo;
	}
	public void setPhoNo(int phoNo) {
		this.phoNo = phoNo;
	}
	
	public int getPhoPostno() {
		return phoPostno;
	}
	public void setPhoPostno(int phoPostno) {
		this.phoPostno = phoPostno;
	}
	public String getPhoPhoto() {
		return phoPhoto;
	}
	public void setPhoPhoto(String phoPhoto) {
		this.phoPhoto = phoPhoto;
	}





}
