
--https:localhost:8000/exweb/member/list.do"

-- 회원정보 저장을 위한 테이블 생성
-- 회원 아이디, mem_id 문자열(최대50바이트)
-- 회원 비번 mem_pass 문자열(최대50바이트)
-- 회원 이름 mem_name 문자열(최대50바이트)
-- 회원 포인트 mem_point 숫자(최대10자리 정수)

--CREATE TABLE member(
--mem_id VARCHAR2(50),
--mem_pass VARCHAR2(50),
--mem_name VARCHAR2(50),
--mem_point NUMBER(10,0),
--PRIMARY KEY (mem_id)
--);  
--
--
--INSERT INTO MEMBER 
--(mem_id, mem_pass, mem_name, mem_point)
--VALUES
--('a001', '1234', '배범수', 100);
--
--COMMIT;
--
--select*from member;
--SELECT mem_id, mem_pass, mem_name, mem_point FROM MEMBER;
--
--
--UPDATE member SET mem_point = 300 WHERE mem_id = 'a003';
--UPDATE member SET mem_point = 356 WHERE mem_id = 'a001';
--COMMIT;
--
--
--
--DELETE FROM MEMBER WHERE mem_id = 'a003';
--COMMIT;




CREATE TABLE member(
mem_id VARCHAR2(50),
mem_pass VARCHAR2(50),
mem_name VARCHAR2(50),
mem_point NUMBER(10,0),
PRIMARY KEY (mem_id)
);  


INSERT INTO MEMBER 
(mem_id, mem_pass, mem_name, mem_point)
VALUES
('s001', '8422', '배범수', 999);

COMMIT;

select*from member;

DELETE FROM MEMBER WHERE mem_id = 's02';
DELETE FROM MEMBER WHERE mem_id = 's020';

--학생 테이블
CREATE TABLE student(
stu_no VARCHAR2(50), -- 학번
stu_name VARCHAR2(50), -- 이름
stu_score NUMBER(10,0), -- 성적
PRIMARY KEY (stu_no)
);  

-- 게시판
CREATE TABLE bbs(
bbs_no NUMBER(10,0), -- 글번호
bbs_title VARCHAR2(100), -- 글제목
bbs_content CLOB, -- CHAR LARGE OBJECT(?) 내용
bbs_writer VARCHAR2(50), -- 작성자(아이디)
bbs_reg_date DATE DEFAULT SYSDATE, -- 글등록일(작성일)
bbs_count NUMBER(10,0) DEFAULT 0, -- 조회수
-- 글 최종수정일, 작성자접속IP주소, ....
PRIMARY KEY(bbs_no),
FOREIGN KEY(bbs_writer) REFERENCES member (mem_id) --MEMID에있는것만 반영가능
);

INSERT INTO bbs(bbs_no,bbs_title,bbs_content,bbs_writer)
values(seq_bbs_no.NEXTVAL,'BBS.inc','테스트내용','공돌이');

INSERT INTO bbs(bbs_no,bbs_title,bbs_content,bbs_writer)
values(seq_bbs_no.NEXTVAL,'BBS.inc','테스트11','공돌이');



SELECT * FROM bbs;

-- 시퀀스 (게시판 글번호를 위한 자동증가 정수값 생성)
CREATE SEQUENCE seq_bbs_no;

SELECT seq_bbs_no.NEXTVAL FROM DUAL; -- 시퀀스의 다음값(증가된 값) 가져오기
SELECT seq_bbs_no.CURRVAL FROM DUAL; -- 시퀀스의 현재값 가져오기



-- 게시판 첨부파일 테이블 AttachVo로 이어짐
CREATE TABLE attach(
att_no NUMBER(10,0) PRIMARY KEY, -- 첨부파일번호 
att_org_name VARCHAR2(255), --원래 파일명
att_new_name VARCHAR2(255), --서버에 저장한 파일명
att_bbs_no NUMBER(10,0), -- 첨부파일이 속한 게시글의 글번호   
FOREIGN KEY (att_bbs_no) REFERENCES bbs (bbs_no)
);

SELECT*FROM attach;

CREATE SEQUENCE seq_att_no; -- 첨부파일번호 생성을 위한 시퀀스
SELECT seq_att_no.nextval FROM dual;

SELECT 
bbs_no, bbs_title, bbs_content, bbs_writer, bbs_reg_date, bbs_count, 
att_no, att_org_name, att_new_name,att_bbs_no
FROM bbs left join attach on bbs_no=att_bbs_no
WHERE bbs_no= 73;

