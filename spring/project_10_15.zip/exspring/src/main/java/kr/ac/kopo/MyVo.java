package kr.ac.kopo;
// 여러 파라미터 값을 받기 위한
public class MyVo {

	private int myNo;
	private String myId;
	
	public int getMyNo() {
		return myNo;
	}
	public void setMyNo(int myNo) {
		this.myNo = myNo;
	}
	public String getMyId() {
		return myId;
	}
	public void setMyId(String myId) {
		this.myId = myId;
	}
	
	
	
}
