package kr.ac.kopo.reply;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper // daoimpl대신 이거를 할 수 있음.
public interface ReplyDao {

	public int insert(ReplyVo vo); //ReplyVo은 명령을 할때 줘야하는 것
	public List<ReplyVo> selectList(int bbsNo); // List<ReplyVo>에 댓글들의 결과를 받고  그 특정 글번호의 글에 달린 댓글들만 가져와야하기 때문에 int타입이다..
	
	
	
	
	
}
