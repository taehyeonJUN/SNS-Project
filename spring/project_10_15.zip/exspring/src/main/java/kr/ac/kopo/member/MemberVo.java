package kr.ac.kopo.member;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

public class MemberVo { //Vo란 DB에서 테이블의 한 행을 저장한다고 보면된다.
	@NotEmpty //null 또는 빈 문자열 저장 금지
	@Size(min=2, max=50) //문자열 길이가 2~50사이
	private String memId;
	@NotEmpty //null 또는 빈 문자열 저장 금지
	@Size(min=2, max=50) //문자열 길이가 2~50사이
	private String memPass;
	
	@NotEmpty @Size(min=2, max=50)
	private String memName;
	@Min(0) //0값 이상만 가능
	private int memPoint;
	
	public String getMemId() {
		return memId;
	}
	public void setMemId(String memId) {
		this.memId = memId;
	}
	public String getMemPass() {
		return memPass;
	}
	public void setMemPass(String memPass) {
		this.memPass = memPass;
	}
	public String getMemName() {
		return memName;
	}
	public void setMemName(String memName) {
		this.memName = memName;
	}
	public int getMemPoint() {
		return memPoint;
	}
	public void setMemPoint(int memPoint) {
		this.memPoint = memPoint;
	}
	
}
