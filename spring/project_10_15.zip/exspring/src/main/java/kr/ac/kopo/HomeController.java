package kr.ac.kopo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

//@Controllerd의 @RequestMapping 메서드는 실행결과로서 스플링에게 모델과 뷰 정보를 알려줘야한다.
// 모델 : 응답에 포함되어야하는 데이터(JSP에서 꺼내어 사용할 데이터)
// 뷰 : 응답 화면 출력을 담당하는 객체 (어떤 JSP로 이동할 것인지에 대한 정보)

@Controller // 웹 요청을 받아서 실행되는 클래스임을 표시 (@WebServlet과 유사한 역할)
public class HomeController {
	
	// 로그 출력을 위한 로거 객체 가져오기
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
//	@RequestMapping으로 어떤 주소와 요청방식으로 요청이 왔을때 실행될 메서드인지를 설정 

		@RequestMapping(value = "/home.do", method = RequestMethod.GET) // @WebServlet에서 home.do / doget와 같은 기능 
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale); // 로그출력 Sysout과 같은 것
		
		Date date = new Date(); // 현재 시간을 담은 객체 생성
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date); // 날짜/시간을 현재 로케일에 맞는 형태의 문자열로 변환
		
		// 모델에 "serverTime"라는 이름으로 formattedDate 변수값을 저장
		// JSP에서는 ${serverTime} 라는 표현으로 formattedDate 변수값을 사용가능
		model.addAttribute("serverTime", formattedDate );
		
		// 화면출력을 위해 이동해할 뷰(JSP)의 이름을 변환
		return "home"; 
	}
	
	// http://localhost:8000/kopo/test.do 주소로 요쳥을 보내면,
	// test.jsp 화면이 나오도록 구현
	@RequestMapping(value = "/test.do", method = RequestMethod.GET)
	public String test( //파라미터값을 받는 어노테이션 @RequestParam
		@RequestParam("myNo") String no, //브라우저에 "myNo"라는 이름의 파라미터 값을 입력하면  no 변수에 저장됨
		int myNo, // 변수명이 파라미터 이름과 같은 경우에는 @RequestParam 생략 가능(자동형변환가능)
		@ModelAttribute("mvo") MyVo mv, // 사용자가 정의한 객체의 변수에는 동일한 이름의 파라미터 값이 자동저장
		MyVo vo, // 얘를 구현하고 싶으면 jsp파일에 ${}안에 첫글자를 소문자로하여 ${myVo.myNo}처럼 작성해준다.
		Model model, ModelMap modelMap, Map map) {

		System.out.println("myNo : " + no); // 위에서 저장된 값을 출력
		System.out.println("myNo : " + myNo); // 위에서 저장된 값을 출력
		System.out.println("mv의 myNo : " + mv.getMyNo() ); // 위에서 저장된 값을 출력
		System.out.println("mv의 myId : " + mv.getMyId() ); // 위에서 저장된 값을 출력
		
		String s = "Hello,Spring!";
		// 변수s를 JSP에서 사용하기 위해서는 모델에 데이터를 저장하여야하는데 방법은 아래와 같다.
		// 모델에 데이터를 추가(저장)하는 방법 : 인자로받은 Model,ModelMap,Map 객체에 데이터를 저장
		// 아래 3개중 한개만 사용해도됨
		model.addAttribute("modelVal", s); // s를 modelVal이름으로 옮기고 jsp에서 $을통해 실행
		modelMap.addAttribute("modelMapVal", s);
		map.put("mapVal", s);
//		map.put("mvo", mv); // 이 방법을 사용하지 앟을거면 위에 @ModelAttribute("mvo") MyVo mv를 선언
		
		
		
		return "test"; 
	}
	
	@RequestMapping("/clock.do")
	public String clock() {
		return "clock";
		
	}
	
	@RequestMapping("/data.do")
	@ResponseBody // 메소드의 반환값 자체가 응답 데이터로 전송되어야 함을 표시
	public Map<String, Object> data() {
		Date d = new Date();
		String ds = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(d);
		int n = (int) (Math.random() * 10);
		
//		now : 2020-07-22 11:42:42, num : 7
//		XML 형식
//		<item>
//				<now>2020-07-22 11:42:42</now>
//				<num>7</num>
//			</item>
		
//		JSON 형식 : 자바스크립트 객체표현과 동일하고, 2가지 다른점 존재
//		(1) 속성이름을 문자열로 표현 (2) 문자열은 쌍따옴표만 사용
		
//		var obj = { now : "2020-07-22 11:42:42", num : 7}; //자바스크립트객체표현
//		{ "now" : "2020-07-22 11:42:42", "num" : 7 } //JSON문자열
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("now",ds);
		map.put("num",n);
		
		return map;
//		return "{ \"now\" : \"" + ds + "\", \"num\" : " +n + " }"; 
		
	}
	
}
