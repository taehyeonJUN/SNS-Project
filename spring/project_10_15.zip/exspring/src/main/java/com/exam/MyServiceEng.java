package com.exam;

import org.springframework.stereotype.Component;

@Component("msEng")
public class MyServiceEng implements MyService{

	@Override
	public String getHelloMsg() {
		return "Hello!";
	}

	@Override
	public String getByeMsg() {
		return "Good !";
	}

}
