package com.exam;

public interface MyService {
	String getHelloMsg();
	String getByeMsg();
}
